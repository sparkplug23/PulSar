var searchData=
[
  ['sharp_5fac_5fremote_5fmodel_5ft_8701',['sharp_ac_remote_model_t',['../IRsend_8h.html#a258e4af12642d613587149fa734e45e7',1,'IRsend.h']]],
  ['swingh_5ft_8702',['swingh_t',['../namespacestdAc.html#aae50ee315fa9c9ec1a4078da40d6b147',1,'stdAc']]],
  ['swingv_5ft_8703',['swingv_t',['../namespacestdAc.html#ac07f224c7bb47cac55dd01f24770ef43',1,'stdAc']]]
];
